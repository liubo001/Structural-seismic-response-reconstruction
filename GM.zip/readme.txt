Complete dataset and code
https://mega.nz/folder/2A01wSaL#dVTrZqPxjRpKSy4pBLURfw